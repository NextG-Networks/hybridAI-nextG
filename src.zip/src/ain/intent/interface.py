from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from loguru import logger

from ain.intent.store import IntentStore, intent_key
from ain.intent.schema import Intent, Expectation, ModifyPatch, Report


class IntentInterface:
    """
    Message-driven Intent Lifecycle Manager (ILM).

    IN topics:
      - intent.create { scope, expectations[], owner?, resources? }
      - intent.modify { intent_id, patch{...} }
      - intent.remove { intent_id }
      - intent.report { intent_id, state, evidence }

    OUT topics:
      - intent.set   (full snapshot)
      - intent.state { intent_id, status, evidence? }
      - intent.error { op, error, payload }
    """

    def __init__(
        self,
        bus,
        store: IntentStore,
        *,
        auto_remove_on_fulfill: bool = False,
        auto_remove_on_violate: bool = False,
    ) -> None:
        self.bus = bus
        self.store = store
        self.auto_remove_on_fulfill = auto_remove_on_fulfill
        self.auto_remove_on_violate = auto_remove_on_violate

    # ---------------------------- Loops ----------------------------

    async def _create_loop(self):
        sub = await self.bus.sub("intent.create")
        while True:
            payload = await sub.get()
            try:
                scope = payload["scope"]
                exps_in = payload["expectations"]
                if not exps_in:
                    raise ValueError("expectations[] required")

                exps = [Expectation(**e) for e in exps_in]
                k = intent_key(scope, exps[0].kpi)

                # Idempotent upsert: reuse the active intent for this key if present
                existing = self.store.get_active_by_key(k)
                if existing:
                    # optional: upsert expectations/resources/owner if provided
                    existing.expectations = exps or existing.expectations
                    if "resources" in payload:
                        existing.resources = payload["resources"]
                    if "owner" in payload:
                        existing.owner = payload["owner"]
                    existing.version += 1
                    existing.updated_at = datetime.now(timezone.utc)
                    self.store.put(existing)

                    await self.bus.pub("intent.set", existing.model_dump())
                    await self.bus.pub(
                        "intent.state",
                        {"intent_id": existing.intent_id, "status": existing.status},
                    )
                    logger.info(f"ILM: reused active intent {existing.intent_id} for {k}")
                    continue

                # Create a new active intent
                intent = Intent(
                    intent_id=payload.get("intent_id", str(uuid.uuid4())),
                    scope=scope,
                    expectations=exps,
                    status="active",
                    owner=payload.get("owner"),
                    resources=payload.get("resources", []),
                    created_at=datetime.now(timezone.utc),
                    updated_at=datetime.now(timezone.utc),
                )
                self.store.put(intent)
                await self.bus.pub("intent.set", intent.model_dump())
                await self.bus.pub(
                    "intent.state",
                    {"intent_id": intent.intent_id, "status": "active"},
                )
                logger.info(f"ILM: created {intent.intent_id}")
            except Exception as e:
                await self.bus.pub(
                    "intent.error", {"op": "create", "error": str(e), "payload": payload}
                )

    async def _modify_loop(self):
        sub = await self.bus.sub("intent.modify")
        while True:
            payload = await sub.get()
            try:
                it = self.store.get(payload["intent_id"])
                if not it:
                    raise KeyError("not_found")
                patch = ModifyPatch(**payload.get("patch", {}))
                # Apply patch via schema helper for consistent versioning + timestamps
                it = it.apply_patch(patch)
                self.store.put(it)
                await self.bus.pub("intent.set", it.model_dump())
                await self.bus.pub(
                    "intent.state", {"intent_id": it.intent_id, "status": it.status}
                )
                logger.info(f"ILM: modified {it.intent_id} → v{it.version}")
            except Exception as e:
                await self.bus.pub(
                    "intent.error", {"op": "modify", "error": str(e), "payload": payload}
                )

    async def _remove_loop(self):
        sub = await self.bus.sub("intent.remove")
        while True:
            payload = await sub.get()
            try:
                it = self.store.get(payload["intent_id"])
                if not it:
                    raise KeyError("not_found")
                # Emit terminal state, then remove from store
                await self.bus.pub(
                    "intent.state",
                    {"intent_id": it.intent_id, "status": "removed"},
                )
                self.store.remove(it.intent_id)
                logger.info(f"ILM: removed {it.intent_id}")
            except Exception as e:
                await self.bus.pub(
                    "intent.error", {"op": "remove", "error": str(e), "payload": payload}
                )

    async def _report_loop(self):
        sub = await self.bus.sub("intent.report")
        while True:
            rep = await sub.get()
            try:
                it = self.store.get(rep["intent_id"])
                if not it:
                    raise KeyError("unknown_intent")

                report = Report(**rep)
                state = report.state

                # Simple FSM
                if state == "in_progress" and it.status == "active":
                    it = it.transition("in_progress")
                elif state == "fulfilled":
                    it = it.transition("fulfilled")
                elif state == "violated":
                    it = it.transition("violated")
                else:
                    # If state is "accepted" or a no-op, just touch timestamp
                    it.touch()

                self.store.put(it)
                await self.bus.pub(
                    "intent.state",
                    {
                        "intent_id": it.intent_id,
                        "status": it.status,
                        "evidence": report.evidence,
                    },
                )

                # Optional auto-remove policy
                should_auto_remove = (
                    (self.auto_remove_on_fulfill and state == "fulfilled")
                    or (self.auto_remove_on_violate and state == "violated")
                )
                if should_auto_remove:
                    await self.bus.pub(
                        "intent.state",
                        {"intent_id": it.intent_id, "status": "removed"},
                    )
                    self.store.remove(it.intent_id)
                    logger.info(f"ILM: auto-removed {it.intent_id} after {state}")

            except Exception as e:
                await self.bus.pub(
                    "intent.error", {"op": "report", "error": str(e), "payload": rep}
                )

    async def run(self):
        await asyncio.gather(
            self._create_loop(),
            self._modify_loop(),
            self._remove_loop(),
            self._report_loop(),
        )
